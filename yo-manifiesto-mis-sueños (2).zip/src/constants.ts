/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Affirmation, Meditation } from './types';

export const MEDITATIONS: Meditation[] = [
  {
    id: 1,
    title: "Meditación de apertura",
    purpose: "Para comenzar tu práctica",
    duration: "10 min",
    script: "Cierra los ojos suavemente. Toma una respiración profunda... inhala lentamente... y exhala, soltando todo lo que no necesitas llevar en este momento. Otra respiración profunda... inhala... y exhala. Siente cómo tu cuerpo se relaja con cada respiración. Hoy estás aquí. Presente. Y eso ya es un acto de amor hacia ti misma. Lleva tu atención al centro de tu pecho — a tu corazón. Imagina que allí hay una pequeña llama dorada, cálida, viva. Esa llama eres tú. Tu esencia. Tu poder creador. Con cada respiración, esa llama crece un poco más. Se expande. Ilumina todo tu pecho, tu corazón, tu cuerpo entero. Siente ese calor dorado recorriendo cada parte de ti. Desde la cabeza hasta los pies. Una luz suave, segura, tuya. Hoy veniste aquí con una intención. Tal vez no la tienes perfectamente definida. No importa. El universo ya sabe lo que necesitas. Solo di mentalmente: 'Estoy lista. Estoy abierta. Estoy aquí.' Quédate en ese silencio unos momentos. Recibiendo. Sin pedir. Sin forzar. Solo siendo. Cuando estés lista, toma una respiración profunda, mueve suavemente los dedos de las manos y los pies, y abre los ojos. Llevas contigo esa llama dorada para todo el día."
  },
  {
    id: 2,
    title: "Meditación para soltar bloqueos",
    purpose: "Libera lo que te detiene",
    duration: "15 min",
    script: "Cierra los ojos. Respira profundo tres veces, cada vez soltando más tensión. Lleva tu atención a tu corazón. Siente su latido. Ese latido que nunca para, que nunca te abandona, que siempre está contigo. Ahora te pido que pienses en algo que cargas. Una preocupación, un miedo, una creencia que te dice que no puedes, que no mereces, que no es para ti. No lo analices — solo obsérvalo. Imagina que ese peso tiene una forma. Un color. Puede ser oscuro, pesado, denso. ¿Dónde lo sientes en tu cuerpo? En el pecho, en el estómago, en los hombros. Ahora pon tu mano sobre esa parte de tu cuerpo. Con amor. Sin juzgar. Y dile: 'Gracias por intentar protegerme. Ya puedes descansar. Ya estoy a salvo.' Imagina que al decir esas palabras, ese peso empieza a suavizarse. Se vuelve más ligero. Como si el amor lo disolviera suavemente. Visualiza una luz blanca y dorada entrando por la coronilla de tu cabeza con cada respiración. Esa luz va directamente al lugar donde guardabas ese peso. Con cada exhalación, liberas un poco más. La oscuridad se transforma en luz. El peso se convierte en espacio. El miedo se convierte en libertad. Ese espacio que se abre dentro de ti ahora está disponible para recibir. Para llenarse de lo que realmente deseas. Amor. Paz. Abundancia. Propósito. Di mentalmente: 'Suelto lo que ya no me sirve con amor y gratitud. Estoy lista para recibir lo que el universo tiene para mí.' Permanece en ese espacio de apertura durante un momento. Respirando. Recibiendo. Libre. Cuando estés lista, toma una respiración profunda y regresa suavemente."
  },
  {
    id: 3,
    title: "Meditación de abundancia",
    purpose: "Activa tu frecuencia de prosperidad",
    duration: "12 min",
    script: "Cierra los ojos. Respira profundo y suelta cualquier pensamiento sobre lo que no tienes. Por los próximos minutos, solo existe lo que ya viene en camino. Imagina que estás de pie en un campo abierto, bajo un cielo despejado de color dorado. El sol brilla cálidamente sobre ti. El aire es suave. Estás completamente segura. En este lugar, la abundancia es natural. El suelo está cubierto de flores. Los árboles dan frutos. El río fluye con claridad. Todo es generoso, expansivo, fértil. Ahora imagina que frente a ti aparece la versión de ti misma que ya vive en abundancia. Es tú — pero libre. Serena. Llena. Mírala. ¿Cómo se mueve? ¿Cómo respira? ¿Qué expresión tiene en su cara? Ella se acerca a ti y te pone la mano sobre el corazón. Sientes un calor dorado pasando de su mano al tuyo. Esa energía es la frecuencia de la abundancia. Ya la conoces. Ya la tienes adentro. Respira esa energía. Siente cómo se expande por tu pecho, por tus brazos, por tus piernas. Todo tu ser vibra en esa frecuencia dorada. Di mentalmente: 'Soy abundante. La prosperidad fluye hacia mí con facilidad. Estoy abierta a recibir todo lo que el universo tiene para mí.' Visualiza lo que deseas manifestar — ya en tus manos, ya en tu vida. Siente la gratitud como si ya fuera real. Sonríe si puedes. Quédate en esa emoción. La mente puede dudar. El corazón no. Confía en lo que sientes. Cuando estés lista, regresa suavemente. Sabes que esa frecuencia de abundancia ahora vive en ti."
  },
  {
    id: 4,
    title: "Meditación del amor propio",
    purpose: "Sana tu relación contigo misma",
    duration: "10 min",
    script: "Cierra los ojos. Mano sobre el corazón. Respira. Hoy viniste a encontrarte contigo misma. Con la parte de ti que a veces criticas, que a veces ignoras, que a veces no crees suficiente. Imagina que frente a ti aparece una versión más joven de ti. Puede ser de cualquier edad. La que más necesitó amor. Mírala con ternura. Ella te mira. En sus ojos hay una pregunta que quizás nunca tuvo respuesta: '¿Soy suficiente? ¿Me quieres?' Acércate a ella. Abrázala con toda la ternura que tienes. Dile en voz suave, o mentalmente: 'Sí. Eres suficiente. Siempre lo has sido. Te amo tal como eres.' Siente cómo ese abrazo te sana a ti también. Porque esa niña también vive en ti. Y merecía escuchar esas palabras. Ahora lleva tu atención a tu propio corazón. Dite a ti misma, con toda la convicción que puedas reunir: 'Me amo. Me respeto. Me cuido. Me elijo. Me merezco todo lo bueno que la vida tiene.' Repite estas palabras hasta que las sientas en el cuerpo, no solo en la mente. Deja que el amor propio llene cada espacio dentro de ti. La manifestación más poderosa que existe es amarte a ti misma completamente. Porque cuando te amas, atraes amor. En todas sus formas. Cuando estés lista, abre los ojos. Y recuerda: mereces tu propio amor más que el de nadie más."
  },
  {
    id: 5,
    title: "Meditación de visualización",
    purpose: "Habita tu vida ideal",
    duration: "15 min",
    script: "Cierra los ojos. Respira profundo. Estás completamente segura, completamente presente. Hoy vamos a visitar tu vida ideal. No como un deseo. Como una realidad que ya existe en otra dimensión, esperando que tú la habites. Imagina que te despiertas mañana en la vida que deseas manifestar. ¿Cómo es ese lugar? ¿Qué ves cuando abres los ojos? ¿Hay luz natural? ¿Cómo huele? ¿Qué escuchas? Siente las sábanas bajo tu cuerpo. La temperatura del aire. La paz que sientes en tu corazón al saber que esta es tu vida. Te levantas. ¿Cómo se siente tu cuerpo? ¿Con energía? ¿Con paz? ¿Con propósito? Camina por ese espacio. Es tuyo. ¿Qué vas a hacer hoy? ¿Con quién? ¿Cómo fluye tu día? Visualiza las escenas con todo el detalle que puedas. No te apresures. Vívelo. ¿Qué trabajo haces o qué creas? ¿Cómo te sientes cuando lo haces? ¿Qué impacto tiene en tu vida y en la de otros? ¿Cómo se ven tus relaciones? ¿Tu salud? ¿Tu energía? ¿Tu paz interior? Siente la gratitud de vivir esta vida. Ahora pon tu mano en tu corazón y di: 'Gracias por esta vida. La recibo. Estoy lista. Ya es mía.' Quédate en esa sensación. Sin prisas. Respirando. Sabiendo que cada momento en esa visualización es una semilla que estás plantando ahora. Cuando estés lista, regresa suavemente. Pero lleva contigo esa emoción — es tu brújula hacia esa vida."
  },
  {
    id: 6,
    title: "Meditación de gratitud profunda",
    purpose: "Eleva tu vibración",
    duration: "8 min",
    script: "Cierra los ojos. Tres respiraciones profundas. Con cada exhalación, sueltas. Piensa en algo — o alguien — que amas profundamente. No lo analices. Solo siente el amor que te genera. Deja que esa emoción se expanda. Que llene tu pecho. Que caliente tu corazón. Eso es la gratitud en su forma más pura. Ahora di mentalmente: 'Gracias por mi vida. Gracias por mi cuerpo que me lleva cada día. Gracias por el aire que respiro. Gracias por la belleza que existe en el mundo.' 'Gracias por las personas que me aman. Gracias por los sueños que tengo. Gracias por los obstáculos que me hicieron más fuerte. Gracias por todo lo que está por llegar.' Siente cómo esa gratitud se convierte en luz dentro de ti. Una luz que brilla hacia afuera. Esa luz es tu frecuencia. Y el universo la ve. Permanece en ese estado de gratitud durante un momento. Sabiendo que en este instante, desde esta frecuencia, estás atrayendo más de lo que agradeces. Abre los ojos. Llevas esa frecuencia contigo. Es tuya."
  },
  {
    id: 7,
    title: "Meditación nocturna",
    purpose: "Programa tu mente antes de dormir",
    duration: "10 min",
    script: "Cierra los ojos. Estás en tu cama, segura, cálida, lista para descansar. Lleva tu atención al cuerpo. Empieza por los pies — suéltalos. Sube a las piernas — suéltalas. Las caderas, el abdomen, el pecho, los rombros, los brazos, las manos, el cuello, el rostro. Todo suelta. Todo se relaja. Tu cuerpo está completamente relajado. Tu mente empieza a serenarse. Piensa en tres cosas que ocurrieron hoy por las que puedes sentir gratitud. Por pequeñas que sean. Un momento de paz. Una sonrisa. Un vaso de agua fría. Cualquier cosa. Siente la gratitud por esos tres momentos. Permite que esa emoción cálida te envuelva como una manta. Ahora imagina que mientras duermes, el universo sigue trabajando para ti. Ordenando piezas. Abriendo puertas. Preparando todo lo que has pedido. Di mentalmente: 'Todo lo que necesito ya está en camino. Duermo en paz porque confío. Mañana me despertaré más cerca de la vida que manifiesto.' 'Soy amada. Estoy protegida. Estoy guiada. Estoy lista.' Deja que el sueño llegue naturalmente. Tu mente inconsciente ahora trabaja con la frecuencia de la manifestación. Duerme en paz, creadora. Mañana será un nuevo día de milagros."
  }
];

export const DAILY_AFFIRMATIONS: Record<number, string> = {
  1: "Soy un imán para la abundancia y las bendiciones.",
  2: "La gratitud abre todas las puertas en mi vida.",
  3: "Merezco todo lo bueno que llega a mi vida.",
  4: "Cada día es un regalo y yo lo recibo con amor.",
  5: "Mi vida mejora de maneras hermosas y sorprendentes.",
  6: "Estoy rodeada de amor, paz y prosperidad.",
  7: "El universo conspira siempre a mi favor.",
  8: "Soy suficiente. Tengo suficiente. Hago suficiente.",
  9: "La abundancia fluye hacia mí con facilidad y gracia.",
  10: "Cada mañana traigo agradecimiento a mi día.",
  11: "Soy una mujer bendecida y próspera.",
  12: "La paz es mi estado natural.",
  13: "Elijo ver la belleza en cada momento.",
  14: "Soy receptiva a todos los milagros del universo.",
  15: "Mi gratitud transforma cada experiencia.",
  16: "Confío en el proceso de mi vida.",
  17: "Cada obstáculo es una oportunidad disfrazada.",
  18: "Vibro en la frecuencia de la abundancia.",
  19: "Soy luz y atraigo luz hacia mí.",
  20: "Mi vida es un milagro en constante expansión.",
  21: "Agradezco quien soy y quien estoy llegando a ser.",
  22: "El amor me rodea en todas sus formas.",
  23: "Soy digna de recibir todo lo que deseo.",
  24: "La gratitud es mi superpoder.",
  25: "Hoy elijo la paz sobre el miedo.",
  26: "Estoy alineada con mi propósito más alto.",
  27: "Confío en el tiempo perfecto del universo.",
  28: "Mi corazón está lleno de gratitud y amor.",
  29: "Soy creadora de mi realidad más hermosa.",
  30: "Gracias, gracias, gracias por esta vida extraordinaria."
};

export const AFFIRMATIONS: Affirmation[] = [
  // Amor propio y merecimiento
  { id: 1, text: "Soy suficiente exactamente como soy en este momento.", category: "Amor propio y merecimiento" },
  { id: 2, text: "Me amo y me acepto completamente, con mis fortalezas y mis imperfecciones.", category: "Amor propio y merecimiento" },
  { id: 3, text: "Merezco todo lo bueno que la vida tiene para ofrecerme.", category: "Amor propio y merecimiento" },
  { id: 4, text: "Soy digna de amor, abundancia, salud y paz.", category: "Amor propio y merecimiento" },
  { id: 5, text: "Mi valor no depende de lo que produzco ni de lo que los demás piensan.", category: "Amor propio y merecimiento" },
  { id: 6, text: "Me trato con amor, amabilidad y compasión todos los días.", category: "Amor propio y merecimiento" },
  { id: 7, text: "Confío en mí misma y en mis decisiones.", category: "Amor propio y merecimiento" },
  { id: 8, text: "Soy mi mayor aliada y me apoyo en todo momento.", category: "Amor propio y merecimiento" },
  { id: 9, text: "Celebro quien soy y quien estoy llegando a ser.", category: "Amor propio y merecimiento" },
  { id: 10, text: "El amor propio es mi base y desde allí creo mi vida.", category: "Amor propio y merecimiento" },

  // Abundancia y prosperidad
  { id: 11, text: "Soy un imán poderoso para la abundancia en todas sus formas.", category: "Abundancia y prosperidad" },
  { id: 12, text: "El dinero fluye hacia mí con facilidad, gracia y frecuencia.", category: "Abundancia y prosperidad" },
  { id: 13, text: "Tengo más que suficiente y siempre habrá más.", category: "Abundancia y prosperidad" },
  { id: 14, text: "Soy próspera y generosa — la abundancia me llega para compartirla.", category: "Abundancia y prosperidad" },
  { id: 15, text: "Mi relación con el dinero es sana, armoniosa y amorosa.", category: "Abundancia y prosperidad" },
  { id: 16, text: "Recibo ingresos desde múltiples fuentes de manera fácil y natural.", category: "Abundancia y prosperidad" },
  { id: 17, text: "Merezco vivir una vida de prosperidad y libertad financiera.", category: "Abundancia y prosperidad" },
  { id: 18, text: "Cada día abro nuevas puertas de abundancia y oportunidad.", category: "Abundancia y prosperidad" },
  { id: 19, text: "La prosperidad es mi estado natural de ser.", category: "Abundancia y prosperidad" },
  { id: 20, text: "Agradezco el dinero que tengo y celebro el que está por llegar.", category: "Abundancia y prosperidad" },

  // Manifestación y ley de atracción
  { id: 21, text: "Todo lo que deseo ya existe y está en camino hacia mí.", category: "Manifestación y ley de atracción" },
  { id: 22, text: "Soy una creadora poderosa de mi propia realidad.", category: "Manifestación y ley de atracción" },
  { id: 23, text: "Mis pensamientos y emociones dan forma a mi mundo.", category: "Manifestación y ley de atracción" },
  { id: 24, text: "Confío en que el universo siempre me da lo que necesito en el momento perfecto.", category: "Manifestación y ley de atracción" },
  { id: 25, text: "Vibro en la frecuencia de lo que deseo manifestar.", category: "Manifestación y ley de atracción" },
  { id: 26, text: "Soy receptiva y abierta a recibir todos los milagros del universo.", category: "Manifestación y ley de atracción" },
  { id: 27, text: "Manifiesto con facilidad porque creo y confío completamente.", category: "Manifestación y ley de atracción" },
  { id: 28, text: "El universo conspira siempre a mi favor.", category: "Manifestación y ley de atracción" },
  { id: 29, text: "Actúo como si todo lo que deseo ya es una realidad en mi vida.", category: "Manifestación y ley de atracción" },
  { id: 30, text: "Cada día mi manifestación está más cerca de materializarse.", category: "Manifestación y ley de atracción" },

  // Paz interior y bienestar
  { id: 31, text: "La paz es mi estado natural y la elijo en cada momento.", category: "Paz interior y bienestar" },
  { id: 32, text: "Suelto con amor todo lo que no está en mi control.", category: "Paz interior y bienestar" },
  { id: 33, text: "Mi mente es serena, clara y tranquila.", category: "Paz interior y bienestar" },
  { id: 34, text: "Confío en el proceso de mi vida aunque no vea el camino completo.", category: "Paz interior y bienestar" },
  { id: 35, text: "Elijo la paz sobre la preocupación en cada situación.", category: "Paz interior y bienestar" },
  { id: 36, text: "Tengo el poder de calmar mi mente y encontrar el centro.", category: "Paz interior y bienestar" },
  { id: 37, text: "La tranquilidad vive en mí y puedo acceder a ella siempre.", category: "Paz interior y bienestar" },
  { id: 38, text: "Respiro profundo y regreso siempre a la calma.", category: "Paz interior y bienestar" },
  { id: 39, text: "Soy paz. Irradio paz. Atraigo paz.", category: "Paz interior y bienestar" },
  { id: 40, text: "Mi bienestar es mi prioridad más importante.", category: "Paz interior y bienestar" },

  // Salud y vitalidad
  { id: 41, text: "Mi cuerpo es fuerte, sano y vibrante.", category: "Salud y vitalidad" },
  { id: 42, text: "Agradezco a mi cuerpo por todo lo que hace por mí cada día.", category: "Salud y vitalidad" },
  { id: 43, text: "Cada célula de mi cuerpo vibra en salud y vitalidad.", category: "Salud y vitalidad" },
  { id: 44, text: "Me nutro con amor: con comida que me alimenta y pensamientos que me sanan.", category: "Salud y vitalidad" },
  { id: 45, text: "Mi cuerpo sana con rapidez y facilidad.", category: "Salud y vitalidad" },
  { id: 46, text: "Tengo energía abundante para vivir mi vida con entusiasmo.", category: "Salud y vitalidad" },
  { id: 47, text: "Escucho a mi cuerpo and le doy lo que necesita con amor.", category: "Salud y vitalidad" },
  { id: 48, text: "La salud es mi estado natural y la mantengo con gratitud.", category: "Salud y vitalidad" },
  { id: 49, text: "Me muevo, respiro y vivo con plenitud y alegría.", category: "Salud y vitalidad" },
  { id: 50, text: "Cada día me siento más fuerte, más sana y más radiante.", category: "Salud y vitalidad" },

  // Relaciones y amor
  { id: 51, text: "Merezco relaciones que me nutren, me respetan y me celebran.", category: "Relaciones y amor" },
  { id: 52, text: "Atraigo personas amorosas, generosas y auténticas a mi vida.", category: "Relaciones y amor" },
  { id: 53, text: "Doy amor desde la abundancia, no desde el miedo a quedarme sin él.", category: "Relaciones y amor" },
  { id: 54, text: "Mis relaciones son un espejo de la relación que tengo conmigo misma.", category: "Relaciones y amor" },
  { id: 55, text: "Tengo límites sanos que honro y que los demás respetan.", category: "Relaciones y amor" },
  { id: 56, text: "Soy amada, valorada y apreciada exactamente como soy.", category: "Relaciones y amor" },
  { id: 57, text: "El amor llega a mí de manera natural y hermosa.", category: "Relaciones y amor" },
  { id: 58, text: "Libero con amor las relaciones que ya no me nutren.", category: "Relaciones y amor" },
  { id: 59, text: "Soy capaz de amar profundamente y de recibir amor completamente.", category: "Relaciones y amor" },
  { id: 60, text: "Las personas correctas siempre encuentran el camino hacia mi vida.", category: "Relaciones y amor" },

  // Propósito y éxito
  { id: 61, text: "Vivo con un propósito claro que me da energía y dirección.", category: "Propósito y éxito" },
  { id: 62, text: "Mi trabajo tiene impacto y valor en el mundo.", category: "Propósito y éxito" },
  { id: 63, text: "Soy exitosa en todo lo que emprendo con amor y dedicación.", category: "Propósito y éxito" },
  { id: 64, text: "El éxito llega a mí de manera natural como resultado de quien soy.", category: "Propósito y éxito" },
  { id: 65, text: "Tengo todo lo que necesito para lograr mis metas más grandes.", category: "Propósito y éxito" },
  { id: 66, text: "Confío en mis habilidades y en el valor que tengo para ofrecer.", category: "Propósito y éxito" },
  { id: 67, text: "Cada paso que doy me acerca más a la vida que deseo vivir.", category: "Propósito y éxito" },
  { id: 68, text: "Soy valiente y doy el siguiente paso aunque tenga miedo.", category: "Propósito y éxito" },
  { id: 69, text: "Mi propósito me guía y el universo me apoya en cada decisión.", category: "Propósito y éxito" },
  { id: 70, text: "Nací para dejar una huella positiva en el mundo.", category: "Propósito y éxito" },

  // Crecimiento y transformación
  { id: 71, text: "Estoy en constante expansión y crecimiento.", category: "Crecimiento y transformación" },
  { id: 72, text: "Cada desafío es una oportunidad de crecer y fortalecerme.", category: "Crecimiento y transformación" },
  { id: 73, text: "Suelto el pasado con amor y abrazo el presente con gratitud.", category: "Crecimiento y transformación" },
  { id: 74, text: "Me permito cambiar, evolucionar y ser diferente a quien era.", category: "Crecimiento y transformación" },
  { id: 75, text: "Soy flexible, adaptable y abierta a nuevas perspectivas.", category: "Crecimiento y transformación" },
  { id: 76, text: "Cada versión de mí ha hecho lo mejor que pudo con lo que tenía.", category: "Crecimiento y transformación" },
  { id: 77, text: "Mi crecimiento beneficia no solo a mí, sino a todos los que me rodean.", category: "Crecimiento y transformación" },
  { id: 78, text: "Aprendo de cada experiencia y la convierto en sabiduría.", category: "Crecimiento y transformación" },
  { id: 79, text: "Me libero de quién fui para convertirme en quién estoy destinada a ser.", category: "Crecimiento y transformación" },
  { id: 80, text: "La transformación más poderosa ocurre cuando me elijo a mí misma.", category: "Crecimiento y transformación" },

  // Gratitud y abundancia de vida
  { id: 81, text: "Soy profundamente agradecida por la vida que tengo.", category: "Gratitud y abundancia de vida" },
  { id: 82, text: "La gratitud abre todas las puertas en mi vida.", category: "Gratitud y abundancia de vida" },
  { id: 83, text: "Veo la belleza y el regalo en cada momento, grande o pequeño.", category: "Gratitud y abundancia de vida" },
  { id: 84, text: "Agradezco tanto lo que tengo como lo que está en camino.", category: "Gratitud y abundancia de vida" },
  { id: 85, text: "Mi corazón está lleno de gratitud y esa gratitud atrae más bendiciones.", category: "Gratitud y abundancia de vida" },
  { id: 86, text: "Celebro cada avance, por pequeño que parezca.", category: "Gratitud y abundancia de vida" },
  { id: 87, text: "La abundancia en mi vida empieza con la gratitud que siento ahora.", category: "Gratitud y abundancia de vida" },
  { id: 88, text: "Tengo más razones para agradecer que para quejarme.", category: "Gratitud y abundancia de vida" },
  { id: 89, text: "Agradezco a las personas, las experiencias y los momentos que me han formado.", category: "Gratitud y abundancia de vida" },
  { id: 90, text: "Vivo en un estado constante de gratitud que eleva mi vibración.", category: "Gratitud y abundancia de vida" },

  // Confianza y fe
  { id: 91, text: "Confío en el plan del universo para mi vida, aunque no lo vea todo.", category: "Confianza y fe" },
  { id: 92, text: "Tengo fe en que todo lo que me sucede tiene un propósito mayor.", category: "Confianza y fe" },
  { id: 93, text: "Suelto el control y confío en el flujo perfecto de la vida.", category: "Confianza y fe" },
  { id: 94, text: "Estoy exactamente donde necesito estar en este momento.", category: "Confianza y fe" },
  { id: 95, text: "El universo siempre me cuida, me guía y me protege.", category: "Confianza y fe" },
  { id: 96, text: "Confío en mi intuición — es la voz del universo hablando a través de mí.", category: "Confianza y fe" },
  { id: 97, text: "Cada puerta que se cierra me dirige hacia algo mejor.", category: "Confianza y fe" },
  { id: 98, text: "La fe me da la fortaleza para seguir cuando todo parece difícil.", category: "Confianza y fe" },
  { id: 99, text: "Confío en el tiempo perfecto del universo — no demasiado pronto, no demasiado tarde.", category: "Confianza y fe" },
  { id: 100, text: "Soy sostenida por una fuerza mayor que siempre quiere lo mejor para mí.", category: "Confianza y fe" },
];

export const CATEGORIES = [
  "Amor propio y merecimiento",
  "Abundancia y prosperidad",
  "Manifestación y ley de atracción",
  "Paz interior y bienestar",
  "Salud y vitalidad",
  "Relaciones y amor",
  "Propósito y éxito",
  "Crecimiento y transformación",
  "Gratitud y abundancia de vida",
  "Confianza y fe"
];
