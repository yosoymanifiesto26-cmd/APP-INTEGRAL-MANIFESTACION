/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Affirmation {
  id: number;
  text: string;
  category: string;
}

export interface Meditation {
  id: number;
  title: string;
  purpose: string;
  duration: string;
  script: string;
}

export interface JournalEntry {
  day: number;
  date: string;
  mood: number;
  morningGratitude: string;
  nightReflection: string;
  completed: boolean;
}

export type Category = 
  | "Amor propio y merecimiento"
  | "Abundancia y prosperidad"
  | "Manifestación y ley de atracción"
  | "Paz interior y bienestar"
  | "Salud y vitalidad"
  | "Relaciones y amor"
  | "Propósito y éxito"
  | "Crecimiento y transformación"
  | "Gratitud y abundancia de vida"
  | "Confianza y fe";
