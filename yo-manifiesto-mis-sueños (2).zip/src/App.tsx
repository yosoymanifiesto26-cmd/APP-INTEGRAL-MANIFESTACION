/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Sparkles, Star, Heart, Moon, Sun, 
  Leaf, Users, Target, RefreshCw, 
  Bookmark, ChevronLeft, ChevronRight, 
  Menu, X, Play, Info, Share2, Search,
  Calendar, CheckCircle2, MessageSquare,
  Clock, Plus, Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { toPng } from 'html-to-image';
import { Affirmation, Category, JournalEntry, Meditation } from './types';
import { AFFIRMATIONS, CATEGORIES, DAILY_AFFIRMATIONS, MEDITATIONS } from './constants';

// Utility for Tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'explore' | 'favorites' | 'focus' | 'journal' | 'meditations' | 'ebook'>('explore');
  const [isLanding, setIsLanding] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'Todas'>('Todas');
  const [favorites, setFavorites] = useState<number[]>([]);
  const [focusedAffirmation, setFocusedAffirmation] = useState<Affirmation | null>(null);
  const [focusedMeditation, setFocusedMeditation] = useState<Meditation | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [downloadingAffirmation, setDownloadingAffirmation] = useState<Affirmation | null>(null);
  const captureRef = useRef<HTMLDivElement>(null);
  const [isMeditating, setIsMeditating] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  
  // New States for local features
  const [repetitionCount, setRepetitionCount] = useState(0);
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [journalEntries, setJournalEntries] = useState<Record<number, JournalEntry>>({});
  const [selectedDay, setSelectedDay] = useState<number>(1);

  // TTS Ref
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Daily Affirmation
  const dailyAffirmation = useMemo(() => {
    const today = new Date().toDateString();
    let hash = 0;
    for (let i = 0; i < today.length; i++) {
       hash = today.charCodeAt(i) + ((hash << 5) - hash);
    }
    const index = Math.abs(hash) % AFFIRMATIONS.length;
    return AFFIRMATIONS[index];
  }, []);

  // Filtered Affirmations
  const filteredAffirmations = useMemo(() => {
    return AFFIRMATIONS.filter(a => {
      const matchesCategory = selectedCategory === 'Todas' || a.category === selectedCategory;
      const matchesSearch = a.text.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchTerm]);

  // Load from local storage
  useEffect(() => {
    const savedFavs = localStorage.getItem('manifesta_favs');
    if (savedFavs) setFavorites(JSON.parse(savedFavs));
    
    const savedNotes = localStorage.getItem('manifesta_notes');
    if (savedNotes) setNotes(JSON.parse(savedNotes));

    const savedJournal = localStorage.getItem('manifesta_journal');
    if (savedJournal) setJournalEntries(JSON.parse(savedJournal));
  }, []);

  const toggleMeditation = (med: Meditation) => {
    if (focusedMeditation?.id === med.id && isMeditating) {
      window.speechSynthesis.cancel();
      setIsMeditating(false);
      return;
    }
    
    window.speechSynthesis.cancel();
    setFocusedMeditation(med);
    setActiveTab('meditations');
    
    const utterance = new SpeechSynthesisUtterance(med.script);
    utterance.lang = 'es-ES';
    utterance.rate = 0.85;
    utterance.pitch = 1.1;

    // Filter for female voices
    const voices = window.speechSynthesis.getVoices();
    const femaleVoice = voices.find(v => (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('mujer') || v.name.toLowerCase().includes(' Helena') || v.name.toLowerCase().includes('Monica')) && v.lang.startsWith('es'));
    if (femaleVoice) utterance.voice = femaleVoice;

    utterance.onend = () => setIsMeditating(false);
    speechRef.current = utterance;
    
    window.speechSynthesis.speak(utterance);
    setIsMeditating(true);
    setIsPaused(false);
  };

  const pauseResumeMeditation = () => {
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const stopMeditation = () => {
    window.speechSynthesis.cancel();
    setIsMeditating(false);
    setIsPaused(false);
  };

  if (isLanding) {
    return (
      <div className="min-h-screen bg-[#080808] text-[#E5E5E5] font-sans selection:bg-[#C5A059]/30 overflow-x-hidden">
        {/* Cinematic Backdrop */}
        <div className="fixed inset-0 z-0">
          <div className="absolute top-[-10%] right-[-10%] w-[70%] h-[70%] bg-[#C5A059]/5 blur-[120px] rounded-full" />
          <div className="absolute bottom-[-10%] left-[-10%] w-[60%] h-[60%] bg-blue-900/5 blur-[120px] rounded-full" />
        </div>

        {/* Navigation Rail */}
        <nav className="fixed top-0 w-full z-50 flex justify-between items-center px-8 py-8 border-b border-white/5 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#C5A059] rounded-xl flex items-center justify-center shadow-lg shadow-[#C5A059]/20">
              <Sparkles className="text-black" size={20} />
            </div>
            <span className="text-lg font-serif italic tracking-tight text-[#E5D5B5]">Manifesta</span>
          </div>
          <div className="hidden md:flex gap-8 text-[10px] uppercase tracking-[0.3em] font-bold text-white/40">
            <a href="#herramientas" className="hover:text-[#C5A059] transition-colors">Herramientas</a>
            <a href="#proceso" className="hover:text-[#C5A059] transition-colors">El Proceso</a>
            <a href="#comunidad" className="hover:text-[#C5A059] transition-colors">Comunidad</a>
          </div>
          <button 
            onClick={() => setIsLanding(false)}
            className="px-6 py-2.5 bg-white/5 hover:bg-[#C5A059] hover:text-black border border-white/10 rounded-full text-[10px] uppercase tracking-widest font-black transition-all"
          >
            Entrar Ahora
          </button>
        </nav>

        {/* Hero Section */}
        <section className="relative z-10 pt-48 pb-32 px-8 flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <p className="text-[#C5A059] text-[10px] uppercase tracking-[0.6em] font-black mb-6">El Ecosistema Completo de Manifestación</p>
            <h1 className="text-7xl md:text-9xl font-serif italic text-[#E5D5B5] mb-12 leading-[1.1] tracking-tight">
              Soy Manifiesta
            </h1>
            <p className="text-white/40 max-w-2xl mx-auto text-lg md:text-xl leading-relaxed mb-12 font-light italic">
              "No manifiestas lo que quieres, manifiestas lo que eres." — Transforma tu realidad con el Ebook de Transformación, el Diario de 30 Días y Meditaciones Guiadas en un solo lugar.
            </p>
            <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
              <a 
                href="https://www.paypal.com/ncp/payment/NZN2W8DS3FUQ8"
                target="_blank"
                rel="noopener noreferrer"
                className="group relative px-12 py-5 bg-[#C5A059] text-black rounded-full font-black text-xs uppercase tracking-[0.3em] overflow-hidden transition-all hover:scale-105 shadow-2xl shadow-[#C5A059]/20 text-center"
              >
                <span className="relative z-10">Comenzar Mi Viaje</span>
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
              </a>
              <button 
                onClick={() => setIsLanding(false)}
                className="flex items-center gap-4 text-white/30 hover:text-white transition-all text-xs font-bold uppercase tracking-widest px-8"
              >
                <Play size={16} fill="currentColor" /> Probar Demo Gratis
              </button>
            </div>
          </motion.div>
        </section>

        {/* Tools Section */}
        <section id="herramientas" className="relative z-10 py-32 px-8 border-t border-white/5">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                icon: <Target className="text-[#C5A059]" size={32} />,
                title: "100+ Afirmaciones",
                desc: "Programación mental profunda con decretos seleccionados para cada área de tu vida. Amor, Abundancia, Poder y Salud."
              },
              {
                icon: <MessageSquare className="text-[#C5A059]" size={32} />,
                title: "Diario de 30 Días",
                desc: "Un sistema de gratitud matutina y nocturna diseñado para reprogramar tu frecuencia vibratoria en tiempo récord."
              },
              {
                icon: <Moon className="text-[#C5A059]" size={32} />,
                title: "Meditaciones Pro",
                desc: "7 sesiones de meditación guiada con voz femenina profesional para alinear tus centros de energía antes de dormir."
              }
            ].map((tool, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="bg-[#111] p-10 rounded-[3rem] border border-white/5 hover:border-[#C5A059]/30 transition-all group"
              >
                <div className="w-16 h-16 bg-black/40 rounded-3xl flex items-center justify-center mb-8 border border-white/5 group-hover:scale-110 transition-transform">
                  {tool.icon}
                </div>
                <h3 className="text-2xl font-serif text-[#E5D5B5] mb-4">{tool.title}</h3>
                <p className="text-white/30 leading-relaxed text-sm">{tool.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Value Pitch */}
        <section id="proceso" className="relative z-10 py-32 px-8 bg-[#C5A059] text-black">
          <div className="max-w-5xl mx-auto flex flex-col md:flex-row gap-20 items-center">
            <div className="flex-1">
              <h2 className="text-5xl md:text-7xl font-serif italic leading-tight mb-8">
                El Arte de<br />Manifestar
              </h2>
              <p className="text-black/60 text-lg leading-relaxed mb-8">
                Manifesta no es solo una aplicación, es un templo digital para tu disciplina espiritual. Hemos combinado la neurociencia de la afirmación con la sabiduría ancestral de la meditación guiada.
              </p>
              <div className="space-y-4">
                {['Acceso Vitalicio', 'Soporte Premium', 'Voz de Mujer Profesional', 'Exportación en HQ PNG'].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 font-bold text-[10px] uppercase tracking-widest">
                    <CheckCircle2 size={16} /> {item}
                  </div>
                ))}
              </div>
            </div>
            <div className="w-full md:w-[400px] aspect-square bg-black rounded-[4rem] p-12 flex flex-col items-center justify-center text-center shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 w-48 h-48 bg-[#C5A059]/20 blur-[80px]" />
               <p className="text-[#C5A059] text-[10px] uppercase tracking-[0.4em] font-black mb-4">Oferta Especial</p>
               <p className="text-5xl font-serif text-[#E5D5B5] mb-2">$19.00</p>
               <p className="text-white/20 text-[10px] uppercase tracking-widest font-bold mb-8 italic line-through decoration-[#C5A059]">Valorado en $97</p>
               <a 
                href="https://www.paypal.com/ncp/payment/NZN2W8DS3FUQ8"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-5 bg-white text-black rounded-full font-black text-[10px] uppercase tracking-widest hover:scale-105 transition-all text-center block"
               >
                 Reclamar Mi Acceso
               </a>
               <p className="mt-8 text-[8px] text-white/20 uppercase tracking-[0.2em]">Acceso Beta • Limitado</p>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="relative z-10 py-20 px-8 border-t border-white/5 text-center">
          <div className="flex flex-col items-center gap-6 mb-12">
            <a 
              href="https://www.tiktok.com/@yosoymanifiesto.26" 
              target="_blank" 
              rel="noreferrer"
              className="flex items-center gap-3 px-6 py-3 bg-white/5 border border-white/10 rounded-2xl hover:bg-[#C5A059] hover:text-black transition-all group"
            >
              <Users size={20} className="group-hover:scale-110 transition-transform" />
              <span className="text-[12px] uppercase tracking-[0.3em] font-black">@yosoymanifiesto.26</span>
            </a>
            <div className="flex items-center gap-4">
              <div className="w-1 h-1 rounded-full bg-[#C5A059]" />
              <span className="text-[10px] uppercase tracking-[0.5em] font-bold text-white/20">COMUNIDAD DE PODER</span>
              <div className="w-1 h-1 rounded-full bg-[#C5A059]" />
            </div>
          </div>
          <p className="text-[10px] text-white/10 font-medium uppercase tracking-[0.2em] mb-4">
            Transformando realidades desde 2024
          </p>
          <div className="flex justify-center gap-8 text-[10px] uppercase tracking-widest font-black text-white/30">
            <a href="#" className="hover:text-[#C5A059] transition-all underline underline-offset-8">Privacidad</a>
            <a href="#" className="hover:text-[#C5A059] transition-all underline underline-offset-8">Socials</a>
            <a href="#" className="hover:text-[#C5A059] transition-all underline underline-offset-8">Contacto</a>
          </div>
        </footer>
      </div>
    );
  }


  const toggleFavorite = (id: number) => {
    const newFavs = favorites.includes(id) 
      ? favorites.filter(fid => fid !== id) 
      : [...favorites, id];
    setFavorites(newFavs);
    localStorage.setItem('manifesta_favs', JSON.stringify(newFavs));
  };

  const saveNote = (id: number, text: string) => {
    const newNotes = { ...notes, [id]: text };
    setNotes(newNotes);
    localStorage.setItem('manifesta_notes', JSON.stringify(newNotes));
  };

  const updateJournalEntry = (day: number, updates: Partial<JournalEntry>) => {
    const defaultEntry: JournalEntry = {
      day,
      date: new Date().toLocaleDateString(),
      mood: 5,
      morningGratitude: '',
      nightReflection: '',
      completed: false
    };
    const newEntries = { 
      ...journalEntries, 
      [day]: { ...(journalEntries[day] || defaultEntry), ...updates } 
    };
    setJournalEntries(newEntries);
    localStorage.setItem('manifesta_journal', JSON.stringify(newEntries));
  };

  const startFocus = (affirmation: Affirmation) => {
    setFocusedAffirmation(affirmation);
    setActiveTab('focus');
    setRepetitionCount(0);
  };

  const downloadAffirmation = async (aff: Affirmation) => {
    setDownloadingAffirmation(aff);
    
    // Wait for the DOM to update so the hidden div is rendered with the correct content
    setTimeout(async () => {
      if (captureRef.current) {
        try {
          const dataUrl = await toPng(captureRef.current, { 
            quality: 0.95,
            pixelRatio: 2,
            cacheBust: true,
          });
          const link = document.createElement('a');
          link.download = `mantra_${aff.id}.png`;
          link.href = dataUrl;
          link.click();
        } catch (err) {
          console.error('Error generating image:', err);
        } finally {
          setDownloadingAffirmation(null);
        }
      }
    }, 100);
  };

  return (
    <div className="flex h-screen bg-[#080808] text-[#E5E5E5] font-sans selection:bg-[#C5A059]/30 overflow-hidden">
      {/* Floating TikTok Badge */}
      <a 
        href="https://www.tiktok.com/@yosoymanifiesto.26" 
        target="_blank" 
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2 bg-black/80 backdrop-blur-md border border-white/10 rounded-full hover:bg-[#C5A059] hover:text-black transition-all shadow-2xl group"
      >
        <div className="w-2 h-2 rounded-full bg-[#C5A059] group-hover:bg-black animate-pulse" />
        <span className="text-[10px] font-black uppercase tracking-widest">@yosoymanifiesto.26</span>
      </a>

      {/* Background Atmosphere */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-[#C5A059]/5 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-900/10 blur-[100px] rounded-full" />
      </div>

      {/* Sidebar / Navigation */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 lg:hidden"
            />
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              className="fixed inset-y-0 left-0 w-80 bg-[#0A0A0A] border-r border-white/5 z-40 flex flex-col p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex flex-col">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#C5A059] to-[#E5D5B5] flex items-center justify-center shadow-lg shadow-[#C5A059]/20">
                      <Sparkles className="text-[#0A0A0A] w-6 h-6" />
                    </div>
                    <h1 className="text-2xl font-serif font-light tracking-wide text-[#E5D5B5]">Manifesta</h1>
                  </div>
                  <a 
                    href="https://www.tiktok.com/@yosoymanifiesto.26" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-[10px] text-[#C5A059] font-bold tracking-[0.2em] mt-2 ml-1 hover:opacity-80 transition-opacity"
                  >
                    @yosoymanifiesto.26
                  </a>
                </div>
                <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 hover:bg-white/5 rounded-full transition-colors">
                  <X size={20} />
                </button>
              </div>

              <nav className="flex-1 space-y-2">
                <NavButton active={activeTab === 'ebook'} icon={<Info size={20} />} label="Ebook de Transformación" onClick={() => { setActiveTab('ebook'); setIsSidebarOpen(false); }} />
                <NavButton active={activeTab === 'meditations'} icon={<Moon size={20} />} label="Meditaciones" onClick={() => { setActiveTab('meditations'); setIsSidebarOpen(false); }} />
                <NavButton active={activeTab === 'journal'} icon={<Calendar size={20} />} label="Diario 30 Días" onClick={() => { setActiveTab('journal'); setIsSidebarOpen(false); }} />
                <NavButton active={activeTab === 'explore'} icon={<Search size={20} />} label="Explorar Todo" onClick={() => { setActiveTab('explore'); setIsSidebarOpen(false); }} />
                <NavButton active={activeTab === 'favorites'} icon={<Bookmark size={20} />} label="Mis Favoritas" onClick={() => { setActiveTab('favorites'); setIsSidebarOpen(false); }} />
                <NavButton active={activeTab === 'focus' && focusedAffirmation !== null} icon={<Play size={20} />} label="Modo Enfoque" onClick={() => { if(focusedAffirmation) { setActiveTab('focus'); setIsSidebarOpen(false); } }} />
              </nav>

              <div className="mt-auto pt-8 border-t border-white/5">
                <div className="bg-[#121212] rounded-2xl p-4 border border-white/5">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold mb-2">Mi Transformación</p>
                  <div className="w-full bg-white/5 h-1.5 rounded-full mb-3 overflow-hidden">
                    <div 
                      className="bg-[#C5A059] h-full transition-all duration-1000" 
                      style={{ width: `${((Object.values(journalEntries) as JournalEntry[]).filter(e => e.completed).length / 30) * 100}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-white/30 text-center uppercase tracking-widest">
                    Día {(Object.values(journalEntries) as JournalEntry[]).filter(e => e.completed).length} de 30 Manifestados
                  </p>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 flex flex-col z-10 overflow-hidden">
        {/* Header */}
        <header className="h-20 flex items-center justify-between px-6 lg:px-12 border-b border-white/5">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(true)} className="p-2 hover:bg-white/5 rounded-xl transition-colors">
              <Menu size={24} className="text-[#C5A059]" />
            </button>
            <div className="hidden sm:block">
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059]/60 font-black">@yosoymanifiesto.26</p>
              <p className="text-sm font-light text-white/40">{new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 rounded-full border border-white/5">
              <Clock className="text-[#C5A059]/60" size={12} />
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Portal Energético Abierto</span>
            </div>
          </div>
        </header>

        {/* Dynamic Content */}
        <div className="flex-1 overflow-y-auto px-6 lg:px-12 py-8 custom-scrollbar">
          <AnimatePresence mode="wait">
            {activeTab === 'explore' && (
              <motion.div
                key="explore"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="max-w-6xl mx-auto space-y-12 pb-20"
              >
                {/* Hero / Daily */}
                <section className="relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-[#1A1A1A] to-[#0A0A0A] rounded-[2rem] border border-white/5" />
                  <div className="relative p-10 flex flex-col md:flex-row items-center gap-10">
                    <div className="flex-1 text-center md:text-left">
                      <div className="flex flex-wrap justify-center md:justify-start items-center gap-3 mb-6">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/20">
                          <Star className="text-[#C5A059] w-3 h-3" />
                          <span className="text-[10px] font-bold uppercase tracking-wider text-[#C5A059]">Mantra del Día</span>
                        </div>
                        <span className="text-[10px] text-white/20 font-bold tracking-[0.2em]">@yosoymanifiesto.26</span>
                      </div>
                      <h2 className="text-3xl md:text-5xl font-serif italic font-light text-[#E5D5B5] leading-tight mb-6">
                        "{dailyAffirmation.text}"
                      </h2>
                      <div className="flex flex-wrap justify-center md:justify-start gap-4">
                        <button 
                          onClick={() => startFocus(dailyAffirmation)}
                          className="px-8 py-3 bg-[#C5A059] text-[#0A0A0A] rounded-full font-bold text-sm tracking-wide transition-transform hover:scale-105 active:scale-95 shadow-xl shadow-[#C5A059]/20"
                        >
                          Enfocarse
                        </button>
                        <button 
                          onClick={() => toggleFavorite(dailyAffirmation.id)}
                          className={cn(
                            "p-3 rounded-full border transition-all",
                            favorites.includes(dailyAffirmation.id) ? "bg-rose-500/10 border-rose-500/50 text-rose-500" : "bg-white/5 border-white/10 text-white/60 hover:border-white/30"
                          )}
                        >
                          <Heart fill={favorites.includes(dailyAffirmation.id) ? "currentColor" : "none"} size={20} />
                        </button>
                      </div>
                    </div>
                    <div className="hidden lg:block w-64 h-64 relative">
                      <div className="absolute inset-0 bg-[#C5A059]/5 rounded-full border border-[#C5A059]/10 animate-spin-slow" />
                      <div className="absolute inset-4 bg-[#C5A059]/10 rounded-full border border-[#C5A059]/20" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Moon className="text-[#C5A059]/30 w-24 h-24" />
                      </div>
                    </div>
                  </div>
                </section>

                {/* Filters */}
                <div className="sticky top-0 bg-[#080808]/80 backdrop-blur-md py-4 z-20 flex flex-col md:flex-row gap-6 items-start md:items-center justify-between">
                  <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar max-w-full">
                    {['Todas', ...CATEGORIES].map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat as any)}
                        className={cn(
                          "px-5 py-2 rounded-full text-[10px] uppercase font-bold tracking-widest transition-all whitespace-nowrap border",
                          selectedCategory === cat 
                            ? "bg-[#C5A059] text-[#0A0A0A] border-[#C5A059]" 
                            : "bg-white/5 text-white/40 border-white/10 hover:border-white/30"
                        )}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20" size={16} />
                    <input 
                      type="text" 
                      placeholder="Filtrar verdades..."
                      className="w-full bg-white/5 border border-white/10 rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-[#C5A059]/50 transition-colors"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>

                {/* Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredAffirmations.map((a) => (
                    <motion.div
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      key={a.id}
                      className="group bg-[#111] p-8 rounded-[2rem] border border-white/5 hover:border-[#C5A059]/30 transition-all hover:bg-[#151515] relative overflow-hidden"
                    >
                      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-[#C5A059]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                      
                      <div className="flex justify-between items-start mb-8">
                        <span className="text-[10px] font-mono text-white/10 tracking-[0.3em]">#{a.id.toString().padStart(3, '0')}</span>
                        <div className="flex gap-2">
                          {notes[a.id] && <MessageSquare size={14} className="text-[#C5A059]/40" />}
                          <button 
                            onClick={() => downloadAffirmation(a)}
                            className="text-white/10 hover:text-[#C5A059] transition-colors"
                            title="Descargar Mantra"
                          >
                            <Download size={18} />
                          </button>
                          <button 
                            onClick={() => toggleFavorite(a.id)}
                            className={cn(
                              "text-white/10 hover:text-rose-500 transition-colors",
                              favorites.includes(a.id) && "text-rose-500 opacity-100"
                            )}
                          >
                            <Heart size={18} fill={favorites.includes(a.id) ? "currentColor" : "none"} />
                          </button>
                        </div>
                      </div>

                      <p className="text-xl font-serif text-[#E5E5E5]/90 leading-relaxed mb-10 min-h-[5rem]">
                        "{a.text}"
                      </p>

                      <div className="flex items-center justify-between border-t border-white/5 pt-6">
                        <div className="flex flex-col">
                          <span className="text-[9px] uppercase tracking-[0.2em] text-[#C5A059]/60 font-black">{a.category}</span>
                          <span className="text-[7px] text-white/20 font-bold tracking-widest mt-1">@yosoymanifiesto.26</span>
                        </div>
                        <button 
                          onClick={() => startFocus(a)}
                          className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#C5A059] hover:text-[#0A0A0A] transition-all group-hover:scale-110 active:scale-95"
                        >
                          <ChevronRight size={18} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'favorites' && (
              <motion.div
                key="favorites"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="max-w-4xl mx-auto py-12"
              >
                <div className="text-center mb-16">
                  <div className="inline-block p-4 rounded-full bg-[#C5A059]/5 border border-[#C5A059]/20 mb-6 font-serif italic text-[#C5A059]">10</div>
                  <h2 className="text-4xl font-serif text-[#E5D5B5] mb-4">Mis Mantras de Poder</h2>
                  <p className="text-white/40 max-w-lg mx-auto">
                    Estas son tus afirmaciones seleccionadas para el ritual. Practícalas con convicción frente al espejo.
                  </p>
                </div>

                {favorites.length === 0 ? (
                  <div className="bg-[#111] border border-dashed border-white/10 rounded-[3rem] p-20 text-center">
                    <Bookmark className="mx-auto text-white/5 mb-6" size={64} />
                    <p className="text-white/30 font-medium italic">Tu lista de poder está vacía.</p>
                    <button 
                      onClick={() => setActiveTab('explore')}
                      className="mt-8 px-8 py-3 bg-white/5 border border-white/10 rounded-full text-[#C5A059] font-bold text-xs uppercase tracking-widest hover:bg-white/10 transition-all"
                    >
                      Seleccionar Afirmaciones
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {favorites.map((fid, idx) => {
                      const aff = AFFIRMATIONS.find(a => a.id === fid);
                      if (!aff) return null;
                      return (
                        <motion.div 
                          key={fid}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0, transition: { delay: idx * 0.05 } }}
                          className="flex items-center gap-6 bg-[#111] p-8 rounded-[2rem] border border-white/5 hover:border-[#C5A059]/20 group"
                        >
                          <span className="text-4xl font-serif text-[#C5A059]/20 group-hover:text-[#C5A059]/40 transition-colors">{(idx + 1).toString().padStart(2, '0')}</span>
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-1">
                              <p className="text-[8px] uppercase tracking-widest text-[#C5A059]/40">{aff.category}</p>
                              <span className="text-[8px] text-white/10 font-bold tracking-widest">by @yosoymanifiesto.26</span>
                            </div>
                            <p className="text-xl font-serif italic text-white/80 leading-relaxed">"{aff.text}"</p>
                          </div>
                          <div className="flex gap-3">
                            <button onClick={() => startFocus(aff)} className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-[#C5A059] hover:text-[#0A0A0A] transition-all shadow-lg active:scale-95">
                              <Play size={20} />
                            </button>
                            <button onClick={() => downloadAffirmation(aff)} className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-white/10 text-white/30 hover:text-[#C5A059] transition-all shadow-lg active:scale-95">
                              <Download size={20} />
                            </button>
                            <button onClick={() => toggleFavorite(fid)} className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-rose-500/20 hover:text-rose-500 transition-all text-rose-500/30 active:scale-95">
                              <X size={20} />
                            </button>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'focus' && focusedAffirmation && (
              <motion.div
                key="focus"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex flex-col items-center justify-center -mt-10 max-w-5xl mx-auto text-center relative"
              >
                <motion.div 
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="mb-16 space-y-10"
                >
                  <p className="text-[10px] uppercase tracking-[0.5em] text-[#C5A059] font-black animate-pulse">Sintoniza tu Vibración</p>
                  <div className="relative inline-block">
                    <h2 className="text-4xl md:text-7xl font-serif italic font-light text-[#E5D5B5] leading-[1.15] max-w-4xl tracking-tight relative z-10">
                      "{focusedAffirmation.text}"
                    </h2>
                    <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-[#C5A059]/30 tracking-[0.3em] uppercase whitespace-nowrap">@yosoymanifiesto.26</span>
                  </div>
                  <div className="flex justify-center items-center gap-6 pt-4">
                    <CategoryIcon category={focusedAffirmation.category} />
                    <span className="text-[10px] uppercase tracking-[0.3em] text-white/30 font-bold">{focusedAffirmation.category}</span>
                  </div>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full pb-10">
                  {/* Instructions */}
                  <div className="p-8 bg-[#111] rounded-[2.5rem] border border-white/5 shadow-2xl">
                    <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-black mb-6 border-b border-white/5 pb-4">Técnica de Manifestación</h3>
                    <ul className="text-left space-y-5 text-sm text-white/40">
                      <li className="flex gap-4 group">
                        <CheckCircle2 size={16} className="text-[#C5A059] opacity-40 group-hover:opacity-100 transition-opacity" />
                        <span className="leading-tight">Mírate a los ojos frente al espejo con seguridad.</span>
                      </li>
                      <li className="flex gap-4 group">
                        <CheckCircle2 size={16} className="text-[#C5A059] opacity-40 group-hover:opacity-100 transition-opacity" />
                        <span className="leading-tight">Declara en voz alta, sintiendo el eco en tu cuerpo.</span>
                      </li>
                      <li className="flex gap-4 group">
                        <CheckCircle2 size={16} className="text-[#C5A059] opacity-40 group-hover:opacity-100 transition-opacity" />
                        <span className="leading-tight">Confía plenamente en que el universo ya lo ha concedido.</span>
                      </li>
                    </ul>
                  </div>

                  {/* Counter */}
                  <div className="p-8 bg-[#111] rounded-[2.5rem] border border-white/5 flex flex-col items-center justify-center relative overflow-hidden group">
                     <div className="absolute inset-0 bg-gradient-to-b from-[#C5A059]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                     <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-black mb-8 relative z-10">Contador Sagrado</h3>
                     <div className="text-7xl font-serif text-[#E5D5B5] mb-8 relative z-10">{repetitionCount}</div>
                     <button 
                        onClick={() => setRepetitionCount(prev => prev + 1)}
                        className="w-20 h-20 rounded-full bg-[#C5A059] text-[#0A0A0A] flex items-center justify-center hover:scale-110 active:scale-90 transition-transform shadow-lg shadow-[#C5A059]/20 relative z-10 ring-4 ring-[#C5A059]/10"
                     >
                        <Plus size={32} strokeWidth={3} />
                     </button>
                     <p className="mt-6 text-[10px] text-white/20 uppercase tracking-widest font-bold">Repite 33 veces mínimo</p>
                  </div>

                  {/* Reflection / Notes */}
                  <div className="p-8 bg-[#111] rounded-[2.5rem] border border-white/5 flex flex-col">
                     <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-black mb-6 border-b border-white/5 pb-4">Diario de Intenciones</h3>
                     <textarea 
                        className="flex-1 bg-black/40 rounded-2xl p-6 text-sm text-white/70 italic leading-relaxed focus:outline-none focus:ring-1 ring-[#C5A059]/30 border border-white/5 resize-none custom-scrollbar"
                        placeholder="Escribe lo que sientes al declarar esta verdad..."
                        value={notes[focusedAffirmation.id] || ''}
                        onChange={(e) => saveNote(focusedAffirmation.id, e.target.value)}
                     />
                     <div className="mt-4 flex items-center justify-between text-[8px] uppercase tracking-widest text-white/20 font-bold">
                        <span>Autoguardado</span>
                        <MessageSquare size={12} />
                     </div>
                  </div>
                </div>

                <div className="mt-8 flex items-center gap-8">
                  <button onClick={() => setActiveTab('explore')} className="flex items-center gap-2 text-white/30 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest">
                    <ChevronLeft size={16} /> Volver a la Guía
                  </button>
                  <div className="w-1 h-1 rounded-full bg-white/10" />
                  <button 
                    onClick={() => downloadAffirmation(focusedAffirmation)}
                    className="flex items-center gap-2 text-white/30 hover:text-[#C5A059] transition-colors text-xs font-bold uppercase tracking-widest"
                  >
                    <Download size={16} /> Descargar Mantra
                  </button>
                  <div className="w-1 h-1 rounded-full bg-white/10" />
                  <button className="flex items-center gap-2 text-white/30 hover:text-[#C5A059] transition-colors text-xs font-bold uppercase tracking-widest">
                    <Share2 size={16} /> Compartir
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'ebook' && (
              <motion.div
                key="ebook"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="max-w-4xl mx-auto py-12 px-6"
              >
                {/* Ebook Header */}
                <div className="text-center mb-20">
                  <div className="w-24 h-24 bg-[#C5A059]/10 rounded-[2rem] border border-[#C5A059]/20 flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-[#C5A059]/10 rotate-3">
                    <Sparkles className="text-[#C5A059]" size={42} />
                  </div>
                  <h2 className="text-6xl font-serif text-[#E5D5B5] mb-6 tracking-tight italic">Soy Manifiesta • Mis Sueños</h2>
                  <p className="text-[#C5A059] text-[10px] uppercase tracking-[0.6em] font-black mb-8 italic">Guía completa para manifestar una vida plena</p>
                  <p className="text-white/40 max-w-2xl mx-auto leading-relaxed italic text-xl border-l border-[#C5A059]/30 pl-8 ml-auto mr-auto">
                    "Este libro es para ti, que alguna vez sentiste que tu vida no tenía sentido. Hoy empieza tu transformación." — Yusmelys Maraguacare
                  </p>
                </div>

                {/* Ebook Navigation / TOC */}
                <div className="bg-[#111] p-8 rounded-[2.5rem] border border-white/5 mb-16">
                  <h4 className="text-[10px] uppercase tracking-[0.3em] text-white/20 font-black mb-6">Contenido del Viaje</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { name: 'Introducción: Tu Poder Creador', id: 'ebook-intro' },
                      { name: 'Capítulo I: El Artista Interior', id: 'ebook-cap1' },
                      { name: 'Capítulo II: Maestría en Manifestación', id: 'ebook-cap2' },
                      { name: 'Capítulo III: Abundancia Total', id: 'ebook-cap3' },
                      { name: 'Capítulo IV: Creación Continua', id: 'ebook-cap4' },
                      { name: 'Conclusión: Tu Obra Maestra', id: 'ebook-conclusion' }
                    ].map((chapter, i) => (
                      <button 
                        key={i} 
                        onClick={() => document.getElementById(chapter.id)?.scrollIntoView({ behavior: 'smooth' })}
                        className="flex items-center gap-4 text-sm text-white/40 hover:text-[#C5A059] transition-colors cursor-pointer group text-left"
                      >
                        <span className="text-[10px] font-mono text-[#C5A059]/30">{i === 0 ? '00' : `0${i}`}</span>
                        <span className="font-serif italic">{chapter.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Ebook Content Scroll */}
                <div className="space-y-32 pb-32">
                  {/* Introducción */}
                  <section id="ebook-intro" className="space-y-12">
                    <div className="flex items-center gap-6">
                       <span className="text-7xl font-serif italic text-[#C5A059]/20">00</span>
                       <h3 className="text-4xl font-serif text-[#E5D5B5] italic">Bienvenida a tu nueva vida</h3>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                      <div className="space-y-6 text-white/50 leading-relaxed text-lg">
                        <h4 className="text-[#C5A059] font-serif italic text-2xl">Tu poder creador</h4>
                        <p>¿Alguna vez te has preguntado por qué hay personas que parecen tenerlo todo — amor, salud, dinero, propósito — mientras otras sienten que, sin importar cuánto se esfuercen, nada cambia? La respuesta no está en la suerte. Está en algo mucho más profundo y accesible: en ti.</p>
                        <p>Cada uno de nosotros nació con un poder creador extraordinario. Ese poder no lo tiene solo un grupo selecto de personas. Lo tienes tú.</p>
                      </div>
                      <div className="space-y-6 text-white/50 leading-relaxed text-lg bg-white/5 p-8 rounded-3xl border border-white/10">
                        <h4 className="text-[#C5A059] font-serif italic text-2xl">El lienzo de tu vida</h4>
                        <p>Imagina que tu vida es un lienzo en blanco. Cada pensamiento es una pincelada. Cada emoción, un color. Tú eres la artista.</p>
                        <div className="pt-6 border-t border-[#C5A059]/20 mt-6">
                           <p className="text-[#E5D5B5] italic font-serif text-lg">"Tu vida no es un accidente. Es una obra maestra en proceso. Y tú tienes el pincel."</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#111] p-10 rounded-[3rem] border border-white/5">
                       <h4 className="text-[#C5A059] font-serif italic text-2xl mb-6">El poder de la Ley de la Atracción</h4>
                       <p className="text-white/50 leading-relaxed text-lg italic mb-6">"Lo semejante atrae a lo semejante."</p>
                       <p className="text-white/40 leading-relaxed">Lo que piensas, sientes y crees, eso es lo que manifiestas en tu vida. Si tu mente está llena de miedo, de carencia, de duda — eso es lo que el universo te devuelve. Pero cuando aprendes a vibrar desde la abundancia... todo cambia.</p>
                    </div>
                  </section>

                  {/* Capítulo I */}
                  <section id="ebook-cap1" className="space-y-12">
                    <div className="flex items-center gap-6">
                       <span className="text-7xl font-serif italic text-[#C5A059]/20">01</span>
                       <h3 className="text-4xl font-serif text-[#E5D5B5] italic">Capítulo I — Desvelando al Artista Interior</h3>
                    </div>

                    <div className="space-y-12">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                          <div className="space-y-6">
                             <h4 className="text-[#C5A059] font-serif italic text-xl uppercase tracking-widest">La mente: tu pincel maestro</h4>
                             <p className="text-white/40 leading-relaxed">Tu mente tiene dos partes: la consciente (decisiones deliberadas) y la inconsciente (creencias, memorias y patrones). Cuando tu mente consciente dice "quiero abundancia" pero tu inconsciente guarda la creencia de "el dinero es difícil", hay un conflicto. Y el inconsciente siempre gana.</p>
                             <div className="p-6 bg-[#C5A059]/10 rounded-2xl border border-[#C5A059]/20">
                                <p className="text-[10px] uppercase tracking-widest font-black text-[#C5A059] mb-3">Ejercicio: Observa tus pensamientos</p>
                                <p className="text-xs text-white/50 italic leading-relaxed">Durante un día completo, lleva un registro de los pensamientos que se repiten. Escribe los 5 más frecuentes y clasifícalos: ¿te acercan o te alejan de lo que deseas?</p>
                             </div>
                          </div>
                          <div className="space-y-6">
                             <h4 className="text-[#C5A059] font-serif italic text-xl uppercase tracking-widest">Creencias limitantes</h4>
                             <p className="text-white/40 leading-relaxed">Una creencia limitante es cualquier pensamiento que te impide creer que mereces o puedes tener lo que deseas. El primer paso para superar una creencia limitante es reconocerla. No puedes cambiar lo que no ves.</p>
                             <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                                <p className="text-[10px] uppercase tracking-widest font-black text-white/30 mb-3">Journaling: Mis creencias limitantes</p>
                                <ul className="text-xs text-white/40 space-y-2 list-disc pl-4 italic">
                                   <li>¿Qué creencias sobre el dinero aprendí de mi familia?</li>
                                   <li>¿Qué me digo a mí misma cuando algo bueno me sucede?</li>
                                   <li>Si no tuviera miedo, ¿qué haría diferente hoy?</li>
                                </ul>
                             </div>
                          </div>
                       </div>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-12 pt-12 border-t border-white/5">
                          <div className="space-y-6">
                             <h4 className="text-[#C5A059] font-serif italic text-2xl">Emoción: el color de tu vida</h4>
                             <p className="text-white/40 leading-relaxed">Las emociones son señales energéticas. Cuando sientes gratitud y amor, vibras en una frecuencia alta que atrae experiencias resonantes.</p>
                          </div>
                          <div className="space-y-6">
                             <h4 className="text-[#C5A059] font-serif italic text-2xl">Visualización: pintando tu futuro</h4>
                             <p className="text-white/40 leading-relaxed">Tu cerebro no distingue entre lo que imaginas y lo que ves. No se trata de ver — se trata de SENTIR ese futuro como si fuera presente.</p>
                          </div>
                       </div>
                    </div>
                  </section>

                  {/* Capítulo II */}
                  <section id="ebook-cap2" className="space-y-12 bg-[#111] p-12 rounded-[4rem] border border-white/5">
                    <div className="flex items-center gap-6 mb-12">
                       <span className="text-7xl font-serif italic text-[#C5A059]/20">02</span>
                       <h3 className="text-4xl font-serif text-[#E5D5B5] italic">Capítulo II — Maestría en la Manifestación</h3>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
                       {[
                         { step: "Pedir claro", desc: "El universo necesita especificaciones, no vaguedades." },
                         { step: "Actuar como", desc: "Vibra en la frecuencia de quien ya tiene lo que desea." },
                         { step: "Recibir agradecido", desc: "La gratitud es el imán más poderoso." }
                       ].map((item, i) => (
                         <div key={i} className="text-center p-8 bg-black/40 rounded-[2rem] border border-white/5">
                            <h5 className="text-[#C5A059] font-serif italic text-xl mb-3">{item.step}</h5>
                            <p className="text-white/20 text-xs leading-relaxed">{item.desc}</p>
                         </div>
                       ))}
                    </div>

                    <div className="space-y-12">
                       <div className="p-10 bg-gradient-to-br from-[#C5A059]/20 to-transparent rounded-[3rem] border border-[#C5A059]/30">
                          <h4 className="text-2xl font-serif text-[#E5D5B5] mb-6 italic">El método 369</h4>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                             <div>
                                <span className="text-3xl font-serif text-[#C5A059]">3x</span>
                                <p className="text-xs text-white/40 mt-2 uppercase tracking-widest font-black">Mañana</p>
                                <p className="text-sm text-white/60 mt-1">Afirmando</p>
                             </div>
                             <div>
                                <span className="text-3xl font-serif text-[#C5A059]">6x</span>
                                <p className="text-xs text-white/40 mt-2 uppercase tracking-widest font-black">Tarde</p>
                                <p className="text-sm text-white/60 mt-1">Expresando gratitud</p>
                             </div>
                             <div>
                                <span className="text-3xl font-serif text-[#C5A059]">9x</span>
                                <p className="text-xs text-white/40 mt-2 uppercase tracking-widest font-black">Noche</p>
                                <p className="text-sm text-white/60 mt-1">Sintiendo la emoción</p>
                             </div>
                          </div>
                          <p className="mt-8 text-xs text-[#C5A059]/60 italic font-medium italic">"Hazlo durante 33 días sin saltarte ninguno."</p>
                       </div>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                          <div className="space-y-6">
                             <h4 className="text-[#C5A059] font-serif italic text-2xl">El poder de las afirmaciones</h4>
                             <p className="text-white/40 leading-relaxed text-sm italic">Son declaraciones poderosas que reprograman tu mente inconsciente. El secreto está en empezar con afirmaciones que tu mente pueda aceptar y escalarlas gradualmente.</p>
                          </div>
                          <div className="space-y-6">
                             <h4 className="text-[#C5A059] font-serif italic text-2xl">Sincronicidad y señales</h4>
                             <p className="text-white/40 leading-relaxed text-sm italic">Cuando empiezas a manifestar conscientemente, el universo comienza a enviarte señales. Números repetidos, canciones con el mensaje perfecto, personas que llegan cuando las necesitas.</p>
                          </div>
                       </div>
                    </div>
                  </section>

                  {/* Capítulo III */}
                  <section id="ebook-cap3" className="space-y-12">
                    <div className="flex items-center gap-6">
                       <span className="text-7xl font-serif italic text-[#C5A059]/20">03</span>
                       <h3 className="text-4xl font-serif text-[#E5D5B5] italic">Capítulo III — Abundancia en Todas las Áreas</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       {[
                         { title: "Relación con el dinero", text: "El dinero es energía. Fluye hacia donde hay apertura y se bloquea donde hay miedo. Transforma tus historias sobre él." },
                         { title: "Salud y bienestar", text: "Tu cuerpo es el vehículo de tu alma. La manifestación de salud empieza en cómo te hablas a ti misma." },
                         { title: "Relaciones plenas", text: "Las relaciones que tienes son un espejo de la relación que tienes contigo misma. Lo que vibres, eso atraes." },
                         { title: "Propósito y pasión", text: "Tu propósito no es algo que tienes que encontrar afuera. Ya está en ti. Está en lo que te apasiona." }
                       ].map((item, i) => (
                         <div key={i} className="p-8 bg-[#111] rounded-[2.5rem] border border-white/5 hover:border-[#C5A059]/20 transition-all">
                            <h5 className="text-[#C5A059] font-serif italic text-xl mb-4 italic">{item.title}</h5>
                            <p className="text-white/30 text-sm leading-relaxed">{item.text}</p>
                         </div>
                       ))}
                    </div>

                    <div className="bg-white/5 p-10 rounded-[3rem] border border-white/10 italic text-center">
                       <p className="text-2xl font-serif text-[#E5D5B5]">"¿Qué actividades me hacen perder la noción del tiempo? Ese es tu regalo único."</p>
                    </div>
                  </section>

                  {/* Capítulo IV */}
                  <section id="ebook-cap4" className="space-y-12">
                    <div className="flex items-center gap-6">
                       <span className="text-7xl font-serif italic text-[#C5A059]/20">04</span>
                       <h3 className="text-4xl font-serif text-[#E5D5B5] italic">Capítulo IV — Vivir en la Creación Continua</h3>
                    </div>

                    <div className="space-y-8">
                       <div className="bg-[#111] p-10 rounded-[3rem] border border-white/5">
                          <h4 className="text-[#C5A059] font-serif italic text-2xl mb-6">Gratitud: la clave de la abundancia</h4>
                          <p className="text-white/40 leading-relaxed text-lg">Existe una diferencia entre gratitud superficial y gratitud transformadora. La transformadora agradece incluso en las dificultades, reconociendo la enseñanza.</p>
                       </div>

                       <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 pt-8">
                          <div className="space-y-8">
                             <h4 className="text-xl font-serif text-[#E5D5B5] italic underline decoration-[#C5A059] underline-offset-8">Hábitos Poderosos</h4>
                             <div className="space-y-6">
                                {[
                                  { h: "01 Ritual matutino", d: "10 minutos para agradecer y visualizar antes del teléfono." },
                                  { h: "02 Journaling diario", d: "Escribir convierte deseos abstractos en intenciones concretas." },
                                  { h: "03 Meditación", d: "5 minutos de silencio calman la mente y abren el canal." },
                                  { h: "04 Afirmaciones", d: "Repite con emoción al menos dos veces al día." },
                                  { h: "05 Ritual nocturno", d: "Repasa 3 momentos positivos. Dale luz a tu inconsciente." }
                                ].map((item, i) => (
                                  <div key={i} className="flex gap-6 group">
                                     <span className="text-[#C5A059] font-mono text-xs font-black">{(i+1).toString().padStart(2, '0')}</span>
                                     <div>
                                        <h6 className="text-[#E5D5B5] font-serif italic text-lg mb-1">{item.h}</h6>
                                        <p className="text-white/30 text-xs">{item.d}</p>
                                     </div>
                                  </div>
                                ))}
                             </div>
                          </div>
                          
                          <div className="bg-[#C5A059]/5 p-10 rounded-[3rem] border border-[#C5A059]/20 flex flex-col justify-center text-center">
                             <h4 className="text-3xl font-serif text-[#E5D5B5] mb-8 italic">Construyendo tu Realidad Ideal</h4>
                             <p className="text-white/40 text-sm italic mb-10 leading-relaxed">"Manifestar no significa quedarse sentada esperando. Significa alinearte con tu visión y dar los pasos que están frente a ti, confiando en que el universo se encargará del resto."</p>
                             <button 
                              onClick={() => setActiveTab('journal')}
                              className="w-full py-4 bg-[#C5A059] text-black rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all"
                             >
                               Empezar mi Diario
                             </button>
                          </div>
                       </div>
                    </div>
                  </section>

                  {/* Conclusión */}
                  <section id="ebook-conclusion" className="relative overflow-hidden py-32 text-center border-t border-white/5">
                     <div className="absolute inset-0 bg-[#C5A059]/5 blur-[120px] rounded-full -translate-y-1/2" />
                     <div className="relative z-10 max-w-2xl mx-auto space-y-12">
                        <h3 className="text-7xl font-serif italic text-[#E5D5B5] leading-tight">Tu Vida, Tu Obra Maestra</h3>
                        <p className="text-white/40 text-xl leading-relaxed italic">"Del caos interior a vivir con claridad y propósito. Ese es tu camino. Y ya empezaste."</p>
                        <div className="pt-12">
                           <p className="text-[10px] uppercase tracking-[0.5em] text-[#C5A059] font-black mb-4">CON AMOR, YUSME</p>
                           <a 
                            href="https://www.tiktok.com/@yosoymanifiesto.26" 
                            target="_blank" 
                            rel="noreferrer"
                            className="inline-flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 rounded-full text-white/30 hover:text-[#C5A059] hover:border-[#C5A059]/40 transition-all font-black text-[10px] tracking-widest"
                           >
                             SIGUE MI VIAJE EN TIKTOK
                           </a>
                        </div>
                     </div>
                  </section>
                </div>

                <div className="mt-20 p-10 text-center border-t border-white/5">
                   <p className="text-[10px] text-white/10 font-bold tracking-[0.4em] uppercase">@yosoymanifiesto.26 • Edición Especial Transformación Holística</p>
                </div>
              </motion.div>
            )}

            {activeTab === 'meditations' && (
              <motion.div
                key="meditations"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="max-w-6xl mx-auto py-12 px-6"
              >
                <div className="text-center mb-16">
                  <div className="w-20 h-20 bg-[#C5A059]/10 rounded-full border border-[#C5A059]/20 flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-[#C5A059]/10">
                    <Moon className="text-[#C5A059]" size={36} />
                  </div>
                  <h2 className="text-5xl font-serif text-[#E5D5B5] mb-6 tracking-tight">Guía de Meditación</h2>
                  <p className="text-white/40 max-w-xl mx-auto leading-relaxed italic">
                    "La meditación no es vaciar la mente. Es aprender a dirigirla." - 7 oasis de paz para tu alma.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {MEDITATIONS.map((med) => (
                    <motion.div
                      key={med.id}
                      whileHover={{ y: -5 }}
                      className={cn(
                        "p-8 rounded-[2.5rem] border transition-all duration-500 relative overflow-hidden group h-full flex flex-col justify-between",
                        focusedMeditation?.id === med.id && isMeditating
                          ? "bg-[#C5A059]/10 border-[#C5A059]/40"
                          : "bg-[#111] border-white/5 hover:border-[#C5A059]/20"
                      )}
                    >
                      <div className="relative z-10">
                        <div className="flex justify-between items-start mb-6">
                          <span className="text-[10px] font-mono text-white/10 tracking-[0.3em]">#{med.id.toString().padStart(2, '0')}</span>
                          <span className="text-[10px] font-bold text-[#C5A059]/60 flex items-center gap-2">
                             <Clock size={12} /> {med.duration}
                          </span>
                        </div>
                        <h3 className="text-2xl font-serif text-[#E5D5B5] mb-4 group-hover:text-[#C5A059] transition-colors">{med.title}</h3>
                        <p className="text-sm text-white/30 mb-8 leading-relaxed italic">"{med.purpose}"</p>
                      </div>

                      <div className="flex items-center gap-4 border-t border-white/5 pt-6 relative z-10">
                        <button 
                          onClick={() => toggleMeditation(med)}
                          className={cn(
                            "flex-1 py-3 rounded-2xl text-[10px] uppercase font-black tracking-widest transition-all",
                            focusedMeditation?.id === med.id && isMeditating
                              ? "bg-rose-500/20 text-rose-500 border border-rose-500/30"
                              : "bg-[#C5A059] text-[#0A0A0A] hover:scale-105 active:scale-95"
                          )}
                        >
                          {focusedMeditation?.id === med.id && isMeditating ? "Detener" : "Sintonizar"}
                        </button>
                        {focusedMeditation?.id === med.id && isMeditating && (
                           <button 
                            onClick={pauseResumeMeditation}
                            className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all"
                           >
                            {isPaused ? <Play size={20} /> : <X size={20} />}
                           </button>
                        )}
                      </div>

                      {focusedMeditation?.id === med.id && isMeditating && (
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="absolute inset-0 bg-gradient-to-t from-[#C5A059]/5 to-transparent pointer-events-none"
                        >
                           <div className="absolute bottom-0 left-0 h-1 bg-[#C5A059] animate-[loading_linear_infinite]" style={{ width: '100%', animationDuration: '3s' }} />
                        </motion.div>
                      )}
                    </motion.div>
                  ))}
                </div>

                {isMeditating && focusedMeditation && (
                  <motion.div 
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[90%] max-w-2xl bg-[#151515] border border-[#C5A059]/30 rounded-[2.5rem] p-8 shadow-2xl backdrop-blur-xl z-50 flex items-center gap-8"
                  >
                    <div className="w-16 h-16 rounded-3xl bg-[#C5A059] text-[#0A0A0A] flex items-center justify-center relative overflow-hidden group">
                       <Moon size={28} className="animate-pulse" />
                    </div>
                    <div className="flex-1">
                       <p className="text-[10px] uppercase tracking-[0.3em] text-[#C5A059] font-black mb-1">Meditando • Voz de Mujer</p>
                       <h4 className="text-xl font-serif text-[#E5D5B5] truncate">{focusedMeditation.title}</h4>
                    </div>
                    <div className="flex items-center gap-4">
                       <button 
                        onClick={pauseResumeMeditation}
                        className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all"
                       >
                        {isPaused ? <Play size={20} /> : <X size={20} className="rotate-45" />}
                       </button>
                       <button 
                        onClick={stopMeditation}
                        className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-500 flex items-center justify-center hover:bg-rose-500/20 transition-all"
                       >
                        <X size={20} />
                       </button>
                    </div>
                  </motion.div>
                )}

                <div className="mt-20 p-10 bg-[#111] rounded-[3rem] border border-white/5 text-center">
                   <p className="text-[10px] text-white/10 font-bold tracking-[0.4em] uppercase">@yosoymanifiesto.26 • Meditaciones Guiadas en Voz de Mujer</p>
                </div>
              </motion.div>
            )}

            {activeTab === 'journal' && (
              <motion.div
                key="journal"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="max-w-6xl mx-auto py-12"
              >
                <div className="text-center mb-16">
                  <div className="w-20 h-20 bg-[#C5A059]/10 rounded-3xl border border-[#C5A059]/20 flex items-center justify-center mx-auto mb-8">
                    <Calendar className="text-[#C5A059]" size={36} />
                  </div>
                  <h2 className="text-5xl font-serif text-[#E5D5B5] mb-6 tracking-tight">Diario de Gratitud</h2>
                  <p className="text-white/40 max-w-xl mx-auto leading-relaxed italic">
                    "Lo que aprecias, se aprecia. Lo que agradeces, crece." - Vive 30 días de transformación consciente.
                  </p>
                </div>

                {/* Progress Grid */}
                <div className="grid grid-cols-3 sm:grid-cols-6 md:grid-cols-10 gap-3 mb-16">
                  {Array.from({ length: 30 }, (_, i) => i + 1).map((day) => {
                    const entry = journalEntries[day];
                    const isCompleted = entry?.completed;
                    return (
                      <button
                        key={day}
                        onClick={() => setSelectedDay(day)}
                        className={cn(
                          "aspect-square rounded-2xl border flex flex-col items-center justify-center transition-all duration-300 relative group",
                          selectedDay === day 
                            ? "border-[#C5A059] bg-[#C5A059]/5 ring-2 ring-[#C5A059]/20" 
                            : isCompleted
                              ? "bg-[#C5A059]/20 border-[#C5A059]/40 text-[#C5A059]"
                              : "bg-[#111] border-white/5 text-white/20 hover:border-white/20"
                        )}
                      >
                        <span className="text-[8px] uppercase tracking-widest opacity-40 mb-1 font-bold">Día</span>
                        <span className="text-2xl font-serif">{day}</span>
                        {isCompleted && (
                          <div className="absolute top-1 right-1">
                            <CheckCircle2 size={10} className="text-[#C5A059]" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Daily Journal Entry Form */}
                <div className="bg-[#111] rounded-[3rem] border border-white/5 p-10 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-[#C5A059]/5 blur-[100px] rounded-full -mr-48 -mt-48" />
                  
                  <div className="relative z-10 space-y-12">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-8 border-b border-white/5">
                      <div>
                        <p className="text-[10px] uppercase tracking-[0.4em] text-[#C5A059] font-black mb-2">Manifestando el Día {selectedDay}</p>
                        <h3 className="text-3xl font-serif text-[#E5D5B5]">"{DAILY_AFFIRMATIONS[selectedDay]}"</h3>
                      </div>
                      <div className="flex items-center gap-4 bg-black/40 p-2 rounded-2xl border border-white/5">
                         <span className="text-[10px] uppercase tracking-widest text-white/20 pl-4">Ánimo</span>
                         {[1, 2, 3, 4, 5].map((m) => (
                           <button 
                            key={m}
                            onClick={() => updateJournalEntry(selectedDay, { mood: m })}
                            className={cn(
                              "w-10 h-10 rounded-xl flex items-center justify-center transition-all",
                              (journalEntries[selectedDay]?.mood || 3) === m 
                                ? "bg-[#C5A059] text-[#0A0A0A]" 
                                : "hover:bg-white/5 text-white/20"
                            )}
                           >
                             {m}
                           </button>
                         ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                      <div className="space-y-6">
                        <div className="flex items-center gap-3">
                          <Sun className="text-[#C5A059]" size={20} />
                          <h4 className="text-xs uppercase tracking-[0.2em] text-white/40 font-bold">Gratitud de la Mañana</h4>
                        </div>
                        <textarea 
                          placeholder="Hoy agradezco especialmente..."
                          className="w-full h-40 bg-black/20 rounded-3xl p-6 text-sm text-[#E5D5B5]/70 italic leading-relaxed focus:outline-none border border-white/5 focus:border-[#C5A059]/30 transition-all resize-none"
                          value={journalEntries[selectedDay]?.morningGratitude || ''}
                          onChange={(e) => updateJournalEntry(selectedDay, { morningGratitude: e.target.value })}
                        />
                      </div>

                      <div className="space-y-6">
                        <div className="flex items-center gap-3">
                          <Moon className="text-[#C5A059]" size={20} />
                          <h4 className="text-xs uppercase tracking-[0.2em] text-white/40 font-bold">Reflexión de la Noche</h4>
                        </div>
                        <textarea 
                          placeholder="El mejor momento de hoy fue..."
                          className="w-full h-40 bg-black/20 rounded-3xl p-6 text-sm text-[#E5D5B5]/70 italic leading-relaxed focus:outline-none border border-white/5 focus:border-[#C5A059]/30 transition-all resize-none"
                          value={journalEntries[selectedDay]?.nightReflection || ''}
                          onChange={(e) => updateJournalEntry(selectedDay, { nightReflection: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-8 border-t border-white/5">
                      <p className="text-[10px] text-white/20 font-medium italic italic">
                        "Antes de cerrar este día, respira profundo y di: Gracias. Gracias. Gracias."
                      </p>
                      <button 
                        onClick={() => updateJournalEntry(selectedDay, { completed: !journalEntries[selectedDay]?.completed })}
                        className={cn(
                          "px-12 py-4 rounded-full font-bold text-xs uppercase tracking-[0.2em] transition-all",
                          journalEntries[selectedDay]?.completed 
                            ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" 
                            : "bg-[#C5A059] text-[#0A0A0A] shadow-xl shadow-[#C5A059]/20"
                        )}
                      >
                        {journalEntries[selectedDay]?.completed ? "Completado" : "Finalizar Día"}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="mt-16 text-center">
                   <p className="text-[10px] text-white/10 font-bold tracking-[0.3em] uppercase">@yosoymanifiesto.26 • Diario de Gratitud 30 Días</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Hidden Capture Element for PNG Generation */}
      <div className="fixed -left-full -top-full pointer-events-none overflow-hidden">
        <div 
          ref={captureRef}
          className="w-[1080px] h-[1080px] bg-[#0A0A0A] flex flex-col items-center justify-center p-20 relative text-center"
          style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, #1A1A1A 0%, #0A0A0A 100%)' }}
        >
          {/* Decorative Elements */}
          <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none">
            <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#C5A059]/10 blur-[150px] rounded-full -mr-[200px] -mt-[200px]" />
            <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-blue-900/10 blur-[150px] rounded-full -ml-[200px] -mb-[200px]" />
          </div>

          <div className="relative z-10 flex flex-col items-center max-w-[800px]">
            <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#C5A059] to-[#E5D5B5] flex items-center justify-center shadow-2xl shadow-[#C5A059]/40 mb-12">
              <Sparkles className="text-[#0A0A0A] w-12 h-12" />
            </div>

            <p className="text-[14px] uppercase tracking-[0.6em] text-[#C5A059] font-black mb-12 animate-pulse">Sintonía de Manifestación</p>
            
            <h2 className="text-[64px] font-serif italic text-[#E5D5B5] leading-[1.2] mb-12 drop-shadow-2xl font-light">
              "{downloadingAffirmation?.text}"
            </h2>

            <div className="w-16 h-[1px] bg-white/10 mb-12" />

            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-4 px-6 py-2 bg-white/5 rounded-full border border-white/10">
                <span className="text-[12px] uppercase tracking-[0.4em] text-white/40 font-bold">
                  {downloadingAffirmation?.category}
                </span>
              </div>
              <p className="text-[14px] font-bold tracking-[0.4em] text-[#C5A059] mt-4 uppercase">@yosoymanifiesto.26</p>
            </div>
          </div>

          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 flex items-center gap-4 text-white/10">
             <div className="w-1.5 h-1.5 rounded-full bg-[#C5A059]/30" />
             <span className="text-[10px] uppercase tracking-[0.5em] font-black">Manifesta App</span>
             <div className="w-1.5 h-1.5 rounded-full bg-[#C5A059]/30" />
          </div>
        </div>
      </div>
    </div>
  );
}

// Sub-components

function NavButton({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-4 px-6 py-4 rounded-[1.25rem] transition-all duration-300 relative group overflow-hidden",
        active 
          ? "bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/20" 
          : "text-white/30 hover:bg-white/5 hover:text-white"
      )}
    >
      {active && (
        <motion.div 
          layoutId="sidebar-active"
          className="absolute left-0 top-0 bottom-0 w-1 bg-[#C5A059] shadow-[0_0_15px_#C5A059]"
        />
      )}
      <span className={cn("transition-transform group-hover:scale-110", active ? "text-[#C5A059]" : "opacity-40")}>
        {icon}
      </span>
      <span className="font-bold text-xs uppercase tracking-widest">{label}</span>
      {active && (
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="ml-auto w-1.5 h-1.5 rounded-full bg-[#C5A059] shadow-[0_0_8px_#C5A059]" />
      )}
    </button>
  );
}

function CategoryIcon({ category }: { category: string }) {
  const size = 16;
  switch (category) {
    case 'Amor propio y merecimiento': return <Heart className="text-rose-400" size={size} />;
    case 'Abundancia y prosperidad': return <RefreshCw className="text-emerald-400" size={size} />;
    case 'Manifestación y ley de atracción': return <Sparkles className="text-blue-400" size={size} />;
    case 'Paz interior y bienestar': return <Moon className="text-indigo-400" size={size} />;
    case 'Salud y vitalidad': return <Leaf className="text-green-400" size={size} />;
    case 'Relaciones y amor': return <Users className="text-pink-400" size={size} />;
    case 'Propósito y éxito': return <Target className="text-amber-400" size={size} />;
    case 'Crecimiento y transformación': return <Sun className="text-orange-400" size={size} />;
    case 'Gratitud y abundancia de vida': return <Heart className="text-yellow-400" size={size} />;
    case 'Confianza y fe': return <Star className="text-purple-400" size={size} />;
    default: return <Sparkles className="text-[#C5A059]" size={size} />;
  }
}
